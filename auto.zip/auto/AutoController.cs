﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace auto
{
    class AutoController
    {

        private DataClasses1DataContext db;
        public AutoController(DataClasses1DataContext db)
        {
            this.db = db;
        }


        public void opslaanAuto(String sKenteken, String Merk, String Type, int iBouwjaar)
        {
            autotbl deAuto = new autotbl();
            deAuto.Kenteken = sKenteken;
            deAuto.Merk = Merk;
            deAuto.Type = Type;
            deAuto.Bouwjaar = iBouwjaar;

            // in de wachtrij zetten om opgeslagen te worden in de db
            db.autotbls.InsertOnSubmit(deAuto);
            // daadwerkelijk doorvoeren naar de db
            db.SubmitChanges();
        }

        public void deleteAuto(autotbl dAuto)
        {
            db.autotbls.DeleteOnSubmit(dAuto);
            db.SubmitChanges();
        }

        public void updateAuto(String sKenteken, String sMerk, String sType, int iBouwjaar)
        {
            var uAuto = (from Auto
                         in db.autotbls
                         where Auto.Kenteken == sKenteken
                         select Auto).Single();
            uAuto.Merk = sMerk;
            uAuto.Type = sType;
            db.SubmitChanges();
        }


        public List<autotbl> geefAlleAutos()
        {
            return null;
        }

        public bool checkKenteken(String sKenteken)
        {
            return false;
        }
    }
}
