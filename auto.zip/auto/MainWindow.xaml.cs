﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace auto
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        DataClasses1DataContext db = new DataClasses1DataContext();
        AutoController ac;

        public MainWindow()
        {
            InitializeComponent();
            ac = new AutoController(db);
            dgAuto.ItemsSource = geefAutos();
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {

            string sKenteken = txtKenteken.Text;
            string sMerk = txtMerk.Text;
            string sType = txtType.Text;
            int iBouwjaar = 0;
            if (Int32.TryParse(txtBouwjaar.Text, out iBouwjaar) == true)
            {
                if (checkKenteken(sKenteken) == true)
                {
                    MessageBox.Show("Kenteken bestaat al!");
                }
                else
                {
                    ac.opslaanAuto(sKenteken, sMerk, sType, iBouwjaar);
                    geefAutos();
                }
            }
            else
            {
                MessageBox.Show("Bouwjaar is ongeldig!");
            }
        }

        public bool checkKenteken(String sKenteken)
        {
            bool bResult = false;
            var lijst = (from auto in db.autotbls
                         where auto.Kenteken.Equals(sKenteken)
                         select auto).ToList();
            if (lijst.Count > 0)
            {
                bResult = true;
            }
            return bResult;
        }

        public List<autotbl> geefAutos()
        {
            return db.autotbls.ToList();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            autotbl dAuto = (autotbl)dgAuto.SelectedItem;
            ac.deleteAuto(dAuto);
            dgAuto.ItemsSource = geefAutos();
        }

        private void btnBtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            autotbl kentekenUpdate = (autotbl)dgAuto.SelectedItem;
            txtKenteken.Text = kentekenUpdate.Kenteken;
            txtMerk.Text = kentekenUpdate.Merk;
            txtType.Text = kentekenUpdate.Type;
        }

        private void wijzig_Click(object sender, RoutedEventArgs e)
        {
            string sKenteken = txtKenteken.Text;
            string sMerk = txtMerk.Text;
            string sType = txtType.Text;
            int sBouwjaar = 0;
            ac.updateAuto(sKenteken, sMerk, sType, sBouwjaar);
            dgAuto.ItemsSource = geefAutos();
        }
    }
}
